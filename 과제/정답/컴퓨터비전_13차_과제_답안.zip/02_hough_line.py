import cv2
import numpy as np

img = cv2.imread('../img/sudoku.jpg')
img2 = img.copy()
h, w = img.shape[:2]
# 그레이 스케일 변환 및 엣지 검출 ---①
imgray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(imgray, 100, 200 )
# 트랙바 이벤트 처리 함수
def onChange(x):
    #rho, theta, threshold 선택 값 수집
    rho   = cv2.getTrackbarPos('rho', 'img')
    theta = cv2.getTrackbarPos('theta', 'img')
    threshold = cv2.getTrackbarPos('threshold', 'img')

    if rho == 0:
       rho = 0.1

    if theta == 0:
       theta = 0.1

    img2 = img.copy()
    lines = cv2.HoughLines(edges, rho/100, np.pi/theta, threshold)
    for line in lines: # 검출된 모든 선 순회
        r,th = line[0] # 거리와 각도wh
        tx, ty = np.cos(th), np.sin(th) # x, y축에 대한 삼각비
        x0, y0 = tx*r, ty*r  #x, y 기준(절편) 좌표
        # 기준 좌표에 빨강색 점 그리기
        cv2.circle(img2, (int(abs(x0)), int(abs(y0))), 3, (0,0,255), -1)
        # 직선 방정식으로 그리기 위한 시작점, 끝점 계산
        x1, y1 = int(x0 + w*(-ty)), int(y0 + h * tx)
        x2, y2 = int(x0 - w*(-ty)), int(y0 - h * tx)
        # 선그리기
        cv2.line(img2, (x1, y1), (x2, y2), (0,255,0), 1)

    cv2.imshow('img', np.hstack((img, img2)))

# 초기 화면 출력

cv2.imshow('img', np.hstack((img, img)))
# 트랙바 이벤트 함수 연결
cv2.createTrackbar('rho',       'img', 100, 100, onChange)
cv2.createTrackbar('theta',     'img', 100, 180, onChange)
cv2.createTrackbar('threshold', 'img', 130, 200, onChange)

cv2.waitKey(0)
cv2.destroyAllWindows()