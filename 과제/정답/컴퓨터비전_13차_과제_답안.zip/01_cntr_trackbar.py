import cv2
import numpy as np

def onChange(x):
    img = cv2.imread("../img/coins_spread1.jpg")
    #img = cv2.imread('../img/shapes_donut.png')
    
    thresh1 = cv2.getTrackbarPos("Threshold1", "contours_track")
    thresh2 = cv2.getTrackbarPos("Threshold2", "contours_track")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (15, 15), 0)
    edged = cv2.Canny(blurred, thresh1, thresh2, 3)
    dilated = cv2.dilate(edged, (1, 1), iterations=2)
    
    # 가장 바깥쪽 컨투어에 대해 모든 좌표 반환 ---③
    contour, hierarchy = cv2.findContours(dilated, cv2.RETR_EXTERNAL, \
                                                     cv2.CHAIN_APPROX_NONE)[-2:]

    # 각각의 컨투의 갯수 출력 ---⑤
    print('도형의 갯수: %d'% (len(contour)))
    
    # 모든 좌표를 갖는 컨투어 그리기, 초록색  ---⑥
    cv2.drawContours(img, contour, -1, (0,255,0), 4)
    
    # 결과 출력 ---⑩
    cv2.imshow('contours_track', img)

img = cv2.imread("../img/coins_spread1.jpg")
cv2.imshow('contours_track', img)
cv2.createTrackbar("Threshold1", "contours_track", 0, 255, onChange)
cv2.createTrackbar("Threshold2", "contours_track", 0, 255, onChange)

cv2.waitKey(0)
cv2.destroyAllWindows()