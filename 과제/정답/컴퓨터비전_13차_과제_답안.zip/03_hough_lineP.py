import cv2
import numpy as np

img = cv2.imread('../img/sudoku.jpg')
img2 = img.copy()
h, w = img.shape[:2]
# 그레이 스케일 변환 및 엣지 검출 ---①
imgray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(imgray, 100, 200 )

# 트랙바 이벤트 처리 함수
def onChange(x):
    #rho, theta, threshold 선택 값 수집
    rho       = cv2.getTrackbarPos('rho', 'img')
    theta     = cv2.getTrackbarPos('theta', 'img')
    threshold = cv2.getTrackbarPos('threshold', 'img')
    minllen   = cv2.getTrackbarPos('minllen', 'img')
    maxlgap   = cv2.getTrackbarPos('maxlgap', 'img')

    if rho == 0:
       rho = 0.1

    if theta == 0:
       theta = 0.1

    img2 = img.copy()
    lines = cv2.HoughLinesP(edges, rho/100, np.pi/theta, threshold, None, minllen, maxlgap)
    for line in lines: # 검출된 모든 선 순회
        # 검출된 선 그리기 ---③
        x1, y1, x2, y2 = line[0]
        cv2.line(img2, (x1,y1), (x2, y2), (0,255,0), 1)

    cv2.imshow('img', np.hstack((img, img2)))

# 초기 화면 출력

cv2.imshow('img', np.hstack((img, img)))
# 트랙바 이벤트 함수 연결
cv2.createTrackbar('rho',       'img', 100, 100, onChange)
cv2.createTrackbar('theta',     'img', 180, 180, onChange)
cv2.createTrackbar('threshold', 'img',  10, 200, onChange)
cv2.createTrackbar('minllen',   'img',  20,  50, onChange)
cv2.createTrackbar('maxlgap',   'img',   2, 100, onChange)
cv2.waitKey(0)
cv2.destroyAllWindows()